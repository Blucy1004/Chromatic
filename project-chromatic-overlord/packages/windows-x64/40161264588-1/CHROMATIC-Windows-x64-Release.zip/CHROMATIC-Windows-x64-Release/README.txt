﻿# CHROMATIC Windows x64 Release

## 실행

1. ZIP 전체를 한 폴더에 압축 해제하세요.
2. 체스 GUI에서는 UCI 엔진으로 `chromatic.exe`를 등록하세요. 모델은 옆의 `default.zero`에서 자동으로 로딩됩니다.
3. 콘솔로 실행하려면 `run-console.cmd`를 더블클릭하세요.

이 패키지는 UCI 체스 엔진입니다. 체스판 GUI는 포함되어 있지 않습니다.
Windows 10 1903+ / Windows 11 x64용이며, 네이티브 실행 검증은 Windows Server 2022 x64에서 수행합니다.
실행에 Python, CMake, Visual Studio 또는 별도 Visual C++ Redistributable 설치는 필요하지 않습니다.

콘솔에서 다음 명령을 차례로 입력하세요.

```
uci
isready
position startpos
go movetime 1000
```

`bestmove` 응답 후 `quit`로 종료합니다. 탐색 중에는 `stop`을 사용할 수 있습니다.
`self-check.cmd`는 패키지 파일 해시와 실제 로딩된 모델을 확인합니다.

## 포함된 엔진과 모델

Operation Overlord 실험 엔진의 Release 빌드입니다. 기존 초기 챔피언(교사128개·200스텝)을 그대로 포함했습니다.
CounterexampleVerify / AdaptiveBudget / ForcingSearch / TacticalVerify / ResearchMetrics는 기본 OFF, Threads는1입니다.
이 패키지 작성은 실험 기능의 기본 활성화나 후보 모델 승격을 의미하지 않습니다.

`MANIFEST.json`과 `SHA256SUMS.txt`에 파일별 SHA-256, 모델과 실행 파일의 출처가 있습니다.
네이티브 패키지 검사 결과는 `validation` 폴더에 포함됩니다. 실제 대국 Elo 개선은 미확정입니다.

## 소스와 재빌드

정확한 대응 C++ 소스, 테스트, 빌드 설정은 `source`에 포함됩니다. GPL-3.0-or-later, 라이선스는 `LICENSE`를 확인하세요.
재빌드가 필요한 경우에만 Visual Studio2022 Desktop C++ 및 CMake3.20+를 설치하고 `rebuild.cmd`를 실행하세요.
원래 배포본·챔피언 파일은 변경하지 않았습니다.
